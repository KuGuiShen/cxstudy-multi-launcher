# -*- coding: utf-8 -*-
"""
学习通（超星）电脑端多开器
-----------------------------
原理：学习通桌面端是 Electron 程序。用不同的 --user-data-dir 启动即可让每个
实例拥有完全独立的登录状态，从而实现多个账号互不影响地同时运行。

本工具负责：
  1. 账号（实例）管理：每个账号绑定一个独立数据目录；
  2. 无限多开：除了保存的账号，还可随时开启“临时多开”；
  3. 停止实例、清空账号数据、清理临时数据。

只调用系统自带的 Python + tkinter，无第三方依赖。
"""

import base64
import ctypes
import json
import os
import queue
import shutil
import subprocess
import sys
import threading
import time
import tkinter as tk
import uuid
from datetime import datetime
from tkinter import filedialog, messagebox, ttk
from ctypes import wintypes

APP_TITLE = "学习通多开器"
CONFIG_NAME = "config.json"

DEFAULT_EXE = r"D:\cxstudy\cxstudy.exe"
DEFAULT_DATA_ROOT = r"D:\cxstudy\profiles"

CREATE_NO_WINDOW = 0x08000000


class _PROCESSENTRY32W(ctypes.Structure):
    _fields_ = [
        ("dwSize", wintypes.DWORD),
        ("cntUsage", wintypes.DWORD),
        ("th32ProcessID", wintypes.DWORD),
        ("th32DefaultHeapID", ctypes.POINTER(ctypes.c_ulong)),
        ("th32ModuleID", wintypes.DWORD),
        ("cntThreads", wintypes.DWORD),
        ("th32ParentProcessID", wintypes.DWORD),
        ("pcPriClassBase", ctypes.c_long),
        ("dwFlags", wintypes.DWORD),
        ("szExeFile", wintypes.WCHAR * 260),
    ]


def toolhelp_pids(exe_name):
    """
    快速列出同名进程 PID（Windows Toolhelp 快照，不经过 WMI/PowerShell）。
    exe_name 如 'cxstudy.exe'，不区分大小写。
    """
    kernel32 = ctypes.windll.kernel32
    snapshot = kernel32.CreateToolhelp32Snapshot(0x00000002, 0)
    if snapshot == -1:
        return set()
    pids = set()
    entry = _PROCESSENTRY32W()
    entry.dwSize = ctypes.sizeof(_PROCESSENTRY32W)
    ok = kernel32.Process32FirstW(snapshot, ctypes.byref(entry))
    while ok:
        if entry.szExeFile.lower() == exe_name.lower():
            pids.add(int(entry.th32ProcessID))
        ok = kernel32.Process32NextW(snapshot, ctypes.byref(entry))
    kernel32.CloseHandle(snapshot)
    return pids


def norm_for_match(path):
    """把路径统一成小写形式，便于在命令行文本里匹配。"""
    return os.path.normcase(os.path.normpath(os.path.abspath(path)))


def ps_query_json(needle):
    """
    用 PowerShell 查询所有学习通进程里命令行包含 needle 的进程。
    返回 Python 对象（list 或 dict）。查询不到时返回 []。
    """
    b64 = base64.b64encode(needle.encode("utf-8")).decode("ascii")
    script = (
        "$ErrorActionPreference = 'SilentlyContinue';"
        "$s = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('%s'));"
        "$ps = Get-CimInstance Win32_Process -Filter \"Name='cxstudy.exe'\" | "
        "Where-Object { $_.CommandLine -and $_.CommandLine -match [regex]::Escape($s) } | "
        "Select-Object ProcessId, CommandLine;"
        "if ($ps) { $ps | ConvertTo-Json -Compress } else { '[]' }"
    ) % b64
    try:
        proc = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive", "-Command", script],
            capture_output=True,
            text=True,
            timeout=20,
            creationflags=CREATE_NO_WINDOW,
        )
        text = (proc.stdout or "").strip()
        if not text:
            return []
        return json.loads(text)
    except Exception:
        return []


def query_process_rows(needle):
    """返回 [{ProcessId, CommandLine}, ...]；查询失败返回空列表。"""
    data = ps_query_json(needle)
    if isinstance(data, dict):
        data = [data]
    rows = []
    for item in data or []:
        try:
            rows.append(
                {
                    "ProcessId": int(item["ProcessId"]),
                    "CommandLine": str(item.get("CommandLine") or ""),
                }
            )
        except Exception:
            continue
    return rows


def find_pids_for_dir(profile_dir):
    """返回所有命令行中包含该实例数据目录的 cxstudy 进程 PID。"""
    return [
        r["ProcessId"]
        for r in query_process_rows(norm_for_match(profile_dir))
        if cmd_contains_path(r["CommandLine"], profile_dir)
    ]


def cmd_contains_path(command_line, profile_dir):
    """判断某进程命令行里是否包含目标目录（忽略大小写与斜杠方向）。"""
    cmd = (command_line or "").replace("\\", "/").lower()
    target = norm_for_match(profile_dir).replace("\\", "/")
    return target in cmd


class DuokaiApp:
    def __init__(self, root):
        self.root = root
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        self.cfg_path = os.path.join(self.base_dir, CONFIG_NAME)
        self.accounts = []      # [{id,name,remark,dir,created}]
        self.exe_path = DEFAULT_EXE
        self.data_root = DEFAULT_DATA_ROOT
        self._busy = False
        self._q = queue.Queue()
        self._starting = set()

        self.load_config()
        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.root.after(150, self._poll_queue)

    # ------------------------------------------------------------- 配置
    def load_config(self):
        default = {
            "exe_path": DEFAULT_EXE,
            "data_root": DEFAULT_DATA_ROOT,
            "accounts": [],
        }
        try:
            with open(self.cfg_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            self.exe_path = str(data.get("exe_path") or DEFAULT_EXE)
            self.data_root = str(data.get("data_root") or DEFAULT_DATA_ROOT)
            accs = data.get("accounts") or []
            for a in accs:
                if isinstance(a, dict) and a.get("dir"):
                    self.accounts.append(
                        {
                            "id": str(a.get("id") or uuid.uuid4().hex[:8]),
                            "name": str(a.get("name") or "未命名账号"),
                            "remark": str(a.get("remark") or ""),
                            "dir": str(a["dir"]),
                            "created": str(a.get("created") or ""),
                        }
                    )
        except FileNotFoundError:
            pass
        except Exception:
            messagebox.showwarning(
                APP_TITLE, "配置文件读取失败，将使用默认设置。\n%s" % self.cfg_path
            )

    def save_config(self):
        data = {
            "exe_path": self.exe_path,
            "data_root": self.data_root,
            "accounts": self.accounts,
        }
        tmp = self.cfg_path + ".tmp"
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            os.replace(tmp, self.cfg_path)
            return True
        except Exception as e:
            messagebox.showerror(APP_TITLE, "保存设置失败：\n%s" % e)
            return False

    # ------------------------------------------------------------- UI
    def _build_ui(self):
        self.root.title(APP_TITLE)
        self.root.geometry("920x580")
        self.root.minsize(780, 500)

        top = ttk.Frame(self.root, padding=(12, 10))
        top.pack(fill="x")

        ttk.Label(top, text="学习通程序：").grid(row=0, column=0, sticky="e", padx=(0, 6))
        self.var_exe = tk.StringVar(value=self.exe_path)
        ttk.Entry(top, textvariable=self.var_exe).grid(row=0, column=1, sticky="we", padx=(0, 6))
        ttk.Button(top, text="浏览…", width=8, command=self.browse_exe).grid(row=0, column=2)

        ttk.Label(top, text="实例数据目录：").grid(row=1, column=0, sticky="e", padx=(0, 6), pady=(6, 0))
        self.var_root = tk.StringVar(value=self.data_root)
        ttk.Entry(top, textvariable=self.var_root).grid(row=1, column=1, sticky="we", padx=(0, 6), pady=(6, 0))
        ttk.Button(top, text="浏览…", width=8, command=self.browse_root).grid(row=1, column=2, pady=(6, 0))
        top.columnconfigure(1, weight=1)

        # 账号列表
        mid = ttk.Frame(self.root, padding=(12, 8))
        mid.pack(fill="both", expand=True)

        columns = ("state", "name", "remark", "dir")
        self.tree = ttk.Treeview(mid, columns=columns, show="headings", selectmode="browse")
        self.tree.heading("state", text="状态")
        self.tree.heading("name", text="账号名称")
        self.tree.heading("remark", text="备注")
        self.tree.heading("dir", text="数据目录")
        self.tree.column("state", width=90, anchor="center")
        self.tree.column("name", width=180, anchor="w")
        self.tree.column("remark", width=180, anchor="w")
        self.tree.column("dir", width=280, anchor="w")
        self.tree.tag_configure("running", foreground="#0a8a2f")
        self.tree.tag_configure("stopped", foreground="#8a8a8a")
        self.tree.tag_configure("starting", foreground="#b06a00")
        vsb = ttk.Scrollbar(mid, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vsb.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vsb.pack(side="right", fill="y")

        # 账号操作按钮
        btn = ttk.Frame(self.root, padding=(12, 0, 12, 6))
        btn.pack(fill="x")
        self.btn_add = ttk.Button(btn, text="新建账号", command=self.add_account)
        self.btn_start = ttk.Button(btn, text="启动选中", command=self.start_selected)
        self.btn_edit = ttk.Button(btn, text="重命名/备注", command=self.edit_account)
        self.btn_clear = ttk.Button(btn, text="清空数据重登", command=self.clear_selected)
        self.btn_stop = ttk.Button(btn, text="停止选中", command=self.stop_selected)
        self.btn_del = ttk.Button(btn, text="删除账号", command=self.delete_account)
        for b in (self.btn_add, self.btn_start, self.btn_edit, self.btn_clear, self.btn_stop, self.btn_del):
            b.pack(side="left", padx=(0, 6))

        # 多开/维护
        extra = ttk.Frame(self.root, padding=(12, 0, 12, 8))
        extra.pack(fill="x")
        self.btn_temp = ttk.Button(extra, text="临时多开（每点一次多一个实例）", command=self.start_temp)
        self.btn_refresh = ttk.Button(extra, text="刷新状态", command=self.refresh)
        self.btn_stop_all = ttk.Button(extra, text="停止全部多开实例", command=self.stop_all_managed)
        self.btn_open_dir = ttk.Button(extra, text="打开数据目录", command=self.open_data_root)
        self.btn_clean_temp = ttk.Button(extra, text="清理临时实例数据", command=self.clean_temp)
        for b in (self.btn_temp, self.btn_refresh, self.btn_stop_all, self.btn_open_dir, self.btn_clean_temp):
            b.pack(side="left", padx=(0, 6))

        status = ttk.Frame(self.root, padding=(12, 0, 12, 10))
        status.pack(fill="x")
        self.lbl_status = ttk.Label(
            status,
            text="就绪。同一账号目录一次只运行一个实例；需要更多窗口请使用“临时多开”。",
            foreground="#444",
        )
        self.lbl_status.pack(side="left")

    # ---------------------------------------------------------- 工具
    def browse_exe(self):
        path = filedialog.askopenfilename(
            title="选择学习通程序（cxstudy.exe）",
            filetypes=[("学习通程序", "*.exe")],
            initialdir=os.path.dirname(self.exe_path) if os.path.exists(self.exe_path) else None,
        )
        if path:
            self.exe_path = path
            self.var_exe.set(path)
            self.save_config()

    def browse_root(self):
        path = filedialog.askdirectory(title="选择多开实例的数据存放目录")
        if path:
            self.data_root = path
            self.var_root.set(path)
            self.save_config()

    def sync_paths_from_entry(self):
        exe = self.var_exe.get().strip().strip('"')
        root = self.var_root.get().strip().strip('"')
        changed = False
        if exe and exe != self.exe_path:
            self.exe_path = exe
            changed = True
        if root and root != self.data_root:
            self.data_root = root
            changed = True
        if changed:
            self.save_config()

    def account_abs_dir(self, acc):
        return os.path.abspath(os.path.join(self.data_root, acc["dir"]))

    def next_account_no(self):
        n = 1
        used = {a["dir"] for a in self.accounts}
        while True:
            name = "acct_%04d" % n
            if name not in used and not os.path.exists(os.path.join(self.data_root, name)):
                return name
            n += 1

    def _selected(self):
        sel = self.tree.selection()
        if not sel:
            return None
        iid = sel[0]
        for acc in self.accounts:
            if acc["id"] == iid:
                return acc
        return None

    def launch_dir(self, profile_dir):
        """真正的启动动作，返回 (成功, 消息)。"""
        if not os.path.exists(self.exe_path):
            return False, "没有找到学习通程序：\n%s" % self.exe_path
        os.makedirs(profile_dir, exist_ok=True)
        args = [self.exe_path, "--user-data-dir=" + profile_dir]
        try:
            subprocess.Popen(
                args,
                cwd=os.path.dirname(self.exe_path),
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP,
            )
            return True, ""
        except Exception as e:
            return False, "启动失败：%s" % e

    def _wait_until_visible(self, profile_dir, before_pids, timeout=60):
        """
        后台线程等待实例进程出现（对比启动前后的 cxstudy 进程表），
        然后触发一次精确的状态刷新。
        """
        deadline = time.time() + timeout
        seen = False
        while time.time() < deadline:
            now = toolhelp_pids("cxstudy.exe")
            if now - before_pids:
                seen = True
                break
            time.sleep(0.7)
        for acc in self.accounts:
            if norm_for_match(self.account_abs_dir(acc)) == norm_for_match(profile_dir):
                self._starting.discard(acc["id"])
        self._q.put(("refresh",))
        self._q.put(("toast", "该实例已完成启动。" if seen else "暂时未检测到新进程，请确认程序是否正常运行。"))

    def _upsert_row(self, acc, state, tag):
        values = (state, acc["name"], acc["remark"], acc["dir"])
        if self.tree.exists(acc["id"]):
            self.tree.item(acc["id"], values=values, tags=(tag,))
        else:
            self.tree.insert("", "end", iid=acc["id"], values=values, tags=(tag,))

    # ------------------------------------------------------- 事件
    def _poll_queue(self):
        try:
            while True:
                kind, *rest = self._q.get_nowait()
                if kind == "refresh":
                    self.refresh()
                elif kind == "toast":
                    self.lbl_status.config(text=rest[0])
        except queue.Empty:
            pass
        self.root.after(120, self._poll_queue)

    def _set_busy(self, busy, text=None):
        self._busy = busy
        state = "disabled" if busy else "normal"
        for w in (
            self.btn_add, self.btn_start, self.btn_edit, self.btn_clear,
            self.btn_stop, self.btn_del, self.btn_temp, self.btn_refresh,
            self.btn_stop_all, self.btn_clean_temp,
        ):
            try:
                w.config(state=state)
            except Exception:
                pass
        if text is not None:
            self.lbl_status.config(text=text)
        self.root.update_idletasks()

    # ---------------------------------------------------- 账号操作
    def add_account(self):
        self.sync_paths_from_entry()
        dialog = AccountDialog(self.root, title="新建账号")
        self.root.wait_window(dialog.top)
        if not dialog.result:
            return
        name, remark = dialog.result
        acc = {
            "id": uuid.uuid4().hex[:8],
            "name": name,
            "remark": remark,
            "dir": self.next_account_no(),
            "created": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }
        self.accounts.append(acc)
        self.save_config()
        self.refresh()
        if messagebox.askyesno(APP_TITLE, "账号已创建。现在启动并登录这个账号吗？"):
            self.start_account(acc)

    def start_selected(self):
        acc = self._selected()
        if acc:
            self.start_account(acc)

    def start_account(self, acc):
        self.sync_paths_from_entry()
        profile = self.account_abs_dir(acc)
        pids = find_pids_for_dir(profile)
        if pids:
            if not messagebox.askyesno(
                APP_TITLE,
                "“%s” 已有实例正在运行。\n"
                "同一数据目录不能开两个相同实例（会互相抢数据）。\n\n"
                "是否先停止当前实例，再重新启动？" % acc["name"],
            ):
                return
            self.stop_dir(profile, quiet=True)
            time.sleep(1.0)
        before = toolhelp_pids("cxstudy.exe")
        ok, msg = self.launch_dir(profile)
        if not ok:
            messagebox.showerror(APP_TITLE, msg)
            return
        self._starting.add(acc["id"])
        self._upsert_row(acc, "启动中", "starting")
        self.lbl_status.config(text="正在启动 “%s”…（首次启动约需 10-20 秒）" % acc["name"])
        threading.Thread(
            target=self._wait_until_visible, args=(profile, before), daemon=True
        ).start()

    def edit_account(self):
        acc = self._selected()
        if not acc:
            messagebox.showinfo(APP_TITLE, "请先选中一个账号。")
            return
        dialog = AccountDialog(
            self.root, title="编辑账号", name=acc["name"], remark=acc["remark"]
        )
        self.root.wait_window(dialog.top)
        if not dialog.result:
            return
        acc["name"], acc["remark"] = dialog.result
        self.save_config()
        self.refresh()

    def delete_account(self):
        acc = self._selected()
        if not acc:
            messagebox.showinfo(APP_TITLE, "请先选中一个账号。")
            return
        delete_data = messagebox.askyesnocancel(
            APP_TITLE,
            "删除账号 “%s”？\n\n"
            "选“是”：连同数据目录一起删除（清除该账号登录状态）。\n"
            "选“否”：只从列表移除，保留数据目录。\n"
            "选“取消”：不删除。\n\n"
            "目录：%s" % (acc["name"], self.account_abs_dir(acc)),
        )
        if delete_data is None:
            return
        profile = self.account_abs_dir(acc)
        self.stop_dir(profile, quiet=True)
        time.sleep(0.8)
        if delete_data:
            try:
                if os.path.isdir(profile):
                    shutil.rmtree(profile)
            except Exception as e:
                messagebox.showerror(APP_TITLE, "数据目录删除失败：\n%s" % e)
                return
        self.accounts = [a for a in self.accounts if a["id"] != acc["id"]]
        self.save_config()
        self.refresh()

    def clear_selected(self):
        """清空账号数据目录 = 退出该账号，下次需要重新扫码登录。"""
        acc = self._selected()
        if not acc:
            messagebox.showinfo(APP_TITLE, "请先选中一个账号。")
            return
        if not messagebox.askyesno(
            APP_TITLE,
            "将清空 “%s” 的全部数据并退出登录。\n"
            "清空后下次启动需要重新扫码/输入账号。\n\n继续吗？" % acc["name"],
        ):
            return
        profile = self.account_abs_dir(acc)
        self.stop_dir(profile, quiet=True)
        time.sleep(1.0)
        try:
            if os.path.isdir(profile):
                shutil.rmtree(profile)
            os.makedirs(profile, exist_ok=True)
        except Exception as e:
            messagebox.showerror(APP_TITLE, "清空失败：\n%s" % e)
            return
        self.refresh()
        if messagebox.askyesno(APP_TITLE, "数据已清空。现在打开新的登录窗口吗？"):
            self.start_account(acc)

    # ---------------------------------------------------- 多开/维护
    def start_temp(self):
        self.sync_paths_from_entry()
        temp_root = os.path.join(self.data_root, "temp")
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        name = "quick_%s_%s" % (stamp, uuid.uuid4().hex[:4])
        profile = os.path.join(temp_root, name)
        before = toolhelp_pids("cxstudy.exe")
        ok, msg = self.launch_dir(profile)
        if not ok:
            messagebox.showerror(APP_TITLE, msg)
            return
        self.lbl_status.config(text="已启动一个临时实例（数据目录：%s）" % profile)
        threading.Thread(
            target=self._wait_until_visible, args=(profile, before), daemon=True
        ).start()

    def stop_selected(self):
        acc = self._selected()
        if not acc:
            messagebox.showinfo(APP_TITLE, "请先选中一个账号。")
            return
        self.stop_dir(self.account_abs_dir(acc))

    def stop_dir(self, profile_dir, quiet=False):
        """停止与某个数据目录关联的全部 cxstudy 进程。"""
        first = find_pids_for_dir(profile_dir)
        if not first:
            if not quiet:
                messagebox.showinfo(APP_TITLE, "该目录当前没有检测到运行中的实例。")
            self.refresh()
            return False
        self._kill_pids(first)
        time.sleep(1.5)
        second = find_pids_for_dir(profile_dir)
        if second:
            self._kill_pids(second)
            time.sleep(1.0)
        rest = find_pids_for_dir(profile_dir)
        self.refresh()
        if rest:
            if not quiet:
                messagebox.showerror(
                    APP_TITLE,
                    "仍有进程无法停止（可能需要以管理员身份运行本工具）。",
                )
            return False
        if not quiet:
            messagebox.showinfo(APP_TITLE, "已停止该实例。")
        return True

    def _kill_pids(self, pids):
        for pid in sorted({int(p) for p in pids if str(p).isdigit()}):
            try:
                subprocess.run(
                    ["taskkill", "/PID", str(pid), "/T", "/F"],
                    capture_output=True,
                    text=True,
                    timeout=20,
                    creationflags=CREATE_NO_WINDOW,
                )
            except Exception:
                pass

    def stop_all_managed(self):
        if not messagebox.askyesno(
            APP_TITLE,
            "将停止本工具创建/管理的全部多开实例\n"
            "（包括临时实例；不影响正常安装的学习通本身）。\n\n继续吗？",
        ):
            return
        pids = find_pids_for_dir(self.data_root)
        if not pids:
            messagebox.showinfo(APP_TITLE, "当前没有检测到由本工具启动的实例。")
            self.refresh()
            return
        self._set_busy(True, "正在停止全部多开实例…")
        try:
            self._kill_pids(pids)
            time.sleep(1.5)
            rest = find_pids_for_dir(self.data_root)
            if rest:
                self._kill_pids(rest)
                time.sleep(1.0)
            left = find_pids_for_dir(self.data_root)
            if left:
                messagebox.showerror(APP_TITLE, "仍有进程无法停止，请尝试以管理员身份运行。")
            else:
                self.lbl_status.config(text="已停止全部多开实例。")
        finally:
            self._set_busy(False)
        self.refresh()

    def clean_temp(self):
        temp_root = os.path.join(self.data_root, "temp")
        if not os.path.isdir(temp_root):
            messagebox.showinfo(APP_TITLE, "还没有临时实例数据。")
            return
        if not messagebox.askyesno(
            APP_TITLE,
            "将删除“临时多开”留下的全部数据目录（登录状态随之清除）。\n"
            "已保存的账号不受影响。\n\n继续吗？",
        ):
            return
        removed = 0
        running_pids = find_pids_for_dir(temp_root)
        if running_pids:
            self._kill_pids(running_pids)
            time.sleep(1.5)
        for name in os.listdir(temp_root):
            p = os.path.join(temp_root, name)
            if os.path.isdir(p):
                try:
                    shutil.rmtree(p)
                    removed += 1
                except Exception:
                    pass
        self.lbl_status.config(text="已清理 %d 个临时数据目录。" % removed)
        self.refresh()

    def open_data_root(self):
        os.makedirs(self.data_root, exist_ok=True)
        os.startfile(self.data_root)  # noqa

    # ------------------------------------------------------- 状态
    def refresh(self):
        if self._busy:
            return
        self.sync_paths_from_entry()
        rows = query_process_rows(norm_for_match(self.data_root))
        running = {}
        for acc in self.accounts:
            profile = self.account_abs_dir(acc)
            pids = [
                r["ProcessId"]
                for r in rows
                if cmd_contains_path(r["CommandLine"], profile)
            ]
            if pids:
                running[acc["id"]] = pids
                self._starting.discard(acc["id"])

        self.tree.delete(*self.tree.get_children())
        for acc in self.accounts:
            pids = running.get(acc["id"])
            if pids:
                state = "运行中"
                tag = "running"
            elif acc["id"] in self._starting:
                state = "启动中"
                tag = "starting"
            else:
                state = "未运行"
                tag = "stopped"
            self.tree.insert(
                "",
                "end",
                iid=acc["id"],
                values=(state, acc["name"], acc["remark"], acc["dir"]),
                tags=(tag,),
            )
        self.lbl_status.config(text="共 %d 个已保存账号，刷新完成。" % len(self.accounts))

    def on_close(self):
        try:
            self.save_config()
        except Exception:
            pass
        self.root.destroy()


class AccountDialog:
    """新建/编辑账号的小对话框。"""

    def __init__(self, parent, title, name="", remark=""):
        self.result = None
        self.top = tk.Toplevel(parent)
        self.top.title(title)
        self.top.transient(parent)
        self.top.grab_set()
        self.top.resizable(False, False)

        frm = ttk.Frame(self.top, padding=16)
        frm.pack(fill="both", expand=True)
        ttk.Label(frm, text="账号名称（必填）").grid(row=0, column=0, sticky="w")
        self.var_name = tk.StringVar(value=name)
        entry = ttk.Entry(frm, textvariable=self.var_name, width=38)
        entry.grid(
            row=1, column=0, sticky="we", pady=(2, 10)
        )
        entry.focus_set()
        ttk.Label(frm, text="备注（可选，例如手机号后四位/用途）").grid(row=2, column=0, sticky="w")
        self.var_remark = tk.StringVar(value=remark)
        ttk.Entry(frm, textvariable=self.var_remark, width=38).grid(
            row=3, column=0, sticky="we", pady=(2, 14)
        )
        btns = ttk.Frame(frm)
        btns.grid(row=4, column=0, sticky="e")
        ttk.Button(btns, text="确定", command=self.ok).pack(side="left", padx=(0, 8))
        ttk.Button(btns, text="取消", command=self.top.destroy).pack(side="left")
        frm.columnconfigure(0, weight=1)
        self.top.bind("<Return>", lambda e: self.ok())
        self.top.bind("<Escape>", lambda e: self.top.destroy())

    def ok(self):
        name = self.var_name.get().strip()
        if not name:
            messagebox.showwarning("提示", "请填写账号名称。", parent=self.top)
            return
        self.result = (name, self.var_remark.get().strip())
        self.top.destroy()


def main():
    root = tk.Tk()
    app = DuokaiApp(root)
    root.after(250, app.refresh)
    root.mainloop()


if __name__ == "__main__":
    main()
